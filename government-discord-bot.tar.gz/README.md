# Government Discord Bot

  A full-featured government bot for Discord roleplay/simulation servers. Handles presidential orders, press briefings, alerts, schedule management, official DMs, role/verification management, staff logging, announcements, and a ticket system.

  ## Features

  | Command | Description |
  |---|---|
  | `/order` | Issue a Presidential Executive Order (posts to `#presidential-orders`) |
  | `/briefing` | Post an official press briefing (posts to `#press-releases`) |
  | `/alert` | Broadcast a government alert at Info / Warning / Critical / Emergency level |
  | `/announce` | Post an official announcement to any channel |
  | `/schedule` | Manage and publish the Presidential Daily Schedule |
  | `/dm` | Send official DMs to individual users and/or entire roles |
  | `/verify` | Verify a member and assign them a role |
  | `/assignrole` | Assign or remove a role from a member |
  | `/stafflog` | View the staff action log |
  | `/ticketpanel` | Post a ticket-creation button panel |
  | `/closeticket` | Close and archive a ticket |
  | `/tickets` | List open tickets |

  All commands support optional image attachments. All embeds use the formal government aesthetic with **Presidential Executive Office** as the footer.

  ## Setup

  ### 1. Prerequisites

  - Node.js 18+
  - A Discord application with a bot user ([Discord Developer Portal](https://discord.com/developers/applications))

  ### 2. Install dependencies

  ```bash
  npm install
  ```

  ### 3. Configure environment variables

  Copy `.env.example` to `.env` and fill in your values:

  ```bash
  cp .env.example .env
  ```

  | Variable | Where to find it |
  |---|---|
  | `DISCORD_BOT_TOKEN` | Developer Portal → Your App → Bot → Token |
  | `DISCORD_CLIENT_ID` | Developer Portal → Your App → General Information → Application ID |
  | `DISCORD_GUILD_ID` | Right-click your server in Discord → Copy Server ID |

  ### 4. Enable required Bot Intents

  In the Developer Portal → Your App → Bot, enable:
  - **Server Members Intent** — required for role-based DMs to work fully
  - **Message Content Intent** — required for ticket transcripts

  ### 5. Deploy slash commands

  This registers all slash commands to your guild:

  ```bash
  npm run deploy-commands
  ```

  ### 6. Run the bot

  **Development (auto-restarts on file changes):**
  ```bash
  npm run dev
  ```

  **Production:**
  ```bash
  npm start
  ```

  ## Channel & Category Conventions

  The bot looks for these channel/category names automatically:

  | Name | Purpose |
  |---|---|
  | `presidential-orders` | Executive orders are posted here |
  | `press-releases` | Press briefings are posted here |
  | `presidential-schedule` | Schedule publications |
  | `announcements` | Default announcement channel |
  | `ticket-logs` | Closed ticket summaries |
  | `Tickets` (category) | New ticket channels are created here |
  | `Staff` (role) | Role that can see ticket channels |

  ## Data Storage

  Bot state is persisted to JSON files in the `data/` directory (auto-created on first run):

  - `data/db.json` — orders, press releases, schedules, staff log
  - `data/tickets.json` — ticket records and transcripts

  ## License

  MIT
  