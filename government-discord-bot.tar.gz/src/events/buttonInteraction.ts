import {
  Client,
  ButtonInteraction,
  ChannelType,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} from "discord.js";
import {
  createTicket,
  getOpenTicketByUser,
  getTicketByChannel,
  closeTicket,
  getNextTicketNumber,
  type TicketMessage,
} from "../lib/tickets.js";
import { logStaffAction } from "../lib/db.js";
import { logger } from "../lib/logger.js";

const STAFF_ROLE_NAME = "Staff";
const TICKET_CATEGORY_NAME = "Tickets";
const TICKET_LOG_CHANNEL_NAME = "ticket-logs";

export function registerButtonInteraction(client: Client) {
  client.on("interactionCreate", async (interaction) => {
    if (!interaction.isButton()) return;
    const btn = interaction as ButtonInteraction;

    if (btn.customId === "ticket_open") {
      await handleOpenTicket(btn);
    } else if (btn.customId === "ticket_close") {
      await handleCloseTicket(btn);
    }
  });
}

async function handleOpenTicket(interaction: ButtonInteraction) {
  const guild = interaction.guild;
  if (!guild) return;

  const existing = getOpenTicketByUser(interaction.user.id);
  if (existing) {
    const ch = guild.channels.cache.get(existing.channelId);
    await interaction.reply({
      content: `You already have an open ticket. Please use ${ch ? `<#${ch.id}>` : "your existing ticket channel"} to continue your inquiry.`,
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    const ticketNumber = getNextTicketNumber();
    const channelName = `ticket-${String(ticketNumber).padStart(4, "0")}-${interaction.user.username
      .toLowerCase()
      .replace(/[^a-z0-9]/g, "")
      .slice(0, 16)}`;

    const staffRole = guild.roles.cache.find((r) => r.name === STAFF_ROLE_NAME);
    const category = guild.channels.cache.find(
      (c) => c.type === ChannelType.GuildCategory && c.name === TICKET_CATEGORY_NAME
    );

    const permissionOverwrites = [
      {
        id: guild.id,
        deny: [PermissionFlagsBits.ViewChannel],
      },
      {
        id: interaction.user.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.AttachFiles,
        ],
      },
    ];

    if (staffRole) {
      permissionOverwrites.push({
        id: staffRole.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.ManageMessages,
          PermissionFlagsBits.AttachFiles,
        ],
      });
    }

    const ticketChannel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category?.id,
      permissionOverwrites,
      topic: `Ticket #${ticketNumber} — ${interaction.user.tag}`,
    });

    createTicket(interaction.user.id, interaction.user.tag, ticketChannel.id);

    const embed = new EmbedBuilder()
      .setColor(0x0a0f2c)
      .setTitle(`TICKET #${String(ticketNumber).padStart(4, "0")}`)
      .setDescription(
        `Thank you for reaching out, <@${interaction.user.id}>.\n\nPlease describe your inquiry, issue, or request in full detail. A staff member will attend to you shortly.\n\nWhen your matter has been resolved, use the button below to close this ticket.`
      )
      .setFooter({ text: "Presidential Executive Office" })
      .setTimestamp();

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("ticket_close")
        .setLabel("Close Ticket")
        .setStyle(ButtonStyle.Danger)
    );

    await ticketChannel.send({
      content: `<@${interaction.user.id}>${staffRole ? ` | <@&${staffRole.id}>` : ""}`,
      embeds: [embed],
      components: [row],
    });

    await interaction.editReply({
      content: `Your ticket has been opened: <#${ticketChannel.id}>`,
    });

    logger.info(`Ticket #${ticketNumber} opened by ${interaction.user.tag}`);
  } catch (err) {
    logger.error(err, "Failed to open ticket");
    await interaction.editReply({
      content: "Failed to create your ticket channel. Please contact a staff member directly.",
    });
  }
}

async function handleCloseTicket(interaction: ButtonInteraction) {
  const guild = interaction.guild;
  if (!guild) return;

  const channelId = interaction.channelId;
  const ticket = getTicketByChannel(channelId);

  if (!ticket) {
    await interaction.reply({
      content: "No active ticket found for this channel.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply();

  const closedTicket = closeTicket(channelId, interaction.user.id, interaction.user.tag);
  if (!closedTicket) {
    await interaction.editReply({ content: "Unable to close this ticket. Please try again." });
    return;
  }

  logStaffAction(
    interaction.user.id,
    interaction.user.tag,
    `Closed ticket for ${ticket.userTag}`,
    ticket.userId,
    ticket.userTag
  );

  const transcriptLines = closedTicket.transcript.map((m: TicketMessage) => {
    const ts = new Date(m.timestamp).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    return `[${ts}] ${m.authorTag}: ${m.content}`;
  });

  const summaryEmbed = new EmbedBuilder()
    .setColor(0x2a0a0a)
    .setTitle("TICKET CLOSED")
    .addFields(
      { name: "Submitted By", value: `${ticket.userTag}`, inline: true },
      { name: "Closed By", value: `${interaction.user.tag}`, inline: true },
      { name: "Messages", value: `${closedTicket.transcript.length}`, inline: true }
    )
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  await interaction.editReply({ embeds: [summaryEmbed] });

  const logChannel = guild.channels.cache.find(
    (c) => c.isTextBased() && c.name === TICKET_LOG_CHANNEL_NAME
  );

  if (logChannel && logChannel.isTextBased()) {
    const logEmbed = new EmbedBuilder()
      .setColor(0x0a0f2c)
      .setTitle("TICKET RECORD")
      .addFields(
        { name: "Ticket", value: ticketChannel(channelId), inline: true },
        { name: "Submitted By", value: `${ticket.userTag}`, inline: true },
        { name: "Closed By", value: `${interaction.user.tag}`, inline: true },
        { name: "Duration", value: formatDuration(ticket.openedAt, new Date().toISOString()), inline: true }
      )
      .setTimestamp();

    if (transcriptLines.length > 0) {
      const transcriptText = transcriptLines.join("\n").slice(0, 1000);
      logEmbed.addFields({ name: "Transcript", value: `\`\`\`${transcriptText}\`\`\`` });
    }

    await logChannel.send({ embeds: [logEmbed] });
  }

  setTimeout(async () => {
    try {
      const ch = guild.channels.cache.get(channelId);
      if (ch) await ch.delete("Ticket closed");
    } catch {
      logger.warn("Could not delete ticket channel");
    }
  }, 5000);
}

function ticketChannel(channelId: string): string {
  return `<#${channelId}>`;
}

function formatDuration(start: string, end: string): string {
  const ms = new Date(end).getTime() - new Date(start).getTime();
  const mins = Math.floor(ms / 60000);
  if (mins < 60) return `${mins} min`;
  const hrs = Math.floor(mins / 60);
  const remMins = mins % 60;
  return `${hrs}h ${remMins}m`;
}
