import { Client, Message } from "discord.js";
import { getTicketByChannel, appendTranscript } from "../lib/tickets.js";

export function registerTicketMessageTracking(client: Client) {
  client.on("messageCreate", async (message: Message) => {
    if (message.author.bot) return;
    if (!message.guild) return;

    const ticket = getTicketByChannel(message.channelId);
    if (!ticket) return;

    appendTranscript(message.channelId, {
      authorId: message.author.id,
      authorTag: message.author.tag,
      content: message.content.slice(0, 500),
      timestamp: message.createdAt.toISOString(),
    });
  });
}
