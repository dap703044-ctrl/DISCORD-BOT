import { Client, Message, ChannelType } from "discord.js";
import { logger } from "../lib/logger.js";

const AUTO_PUBLISH_CHANNEL_NAMES = ["announcements", "presidential-orders", "press-releases", "presidential-schedule", "alerts"];

export function registerMessageCreate(client: Client) {
  client.on("messageCreate", async (message: Message) => {
    if (message.author.bot) return;

    const channel = message.channel;
    if (!channel.isTextBased()) return;

    const channelName = "name" in channel ? (channel.name ?? "") : "";

    if (
      AUTO_PUBLISH_CHANNEL_NAMES.includes(channelName) &&
      channel.type === ChannelType.GuildAnnouncement
    ) {
      try {
        if (!message.flags.has("Crossposted")) {
          await message.crosspost();
          logger.info(`Auto-published message in #${channelName}`);
        }
      } catch (err) {
        logger.warn(err, `Failed to auto-publish in #${channelName}`);
      }
    }
  });
}
