import { Client, Interaction } from "discord.js";
import { commandMap } from "../commands/index.js";
import { logger } from "../lib/logger.js";

export function registerInteractionCreate(client: Client) {
  client.on("interactionCreate", async (interaction: Interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const command = commandMap.get(interaction.commandName);
    if (!command) {
      logger.warn(`Unknown command: ${interaction.commandName}`);
      return;
    }

    try {
      await command.execute(interaction);
    } catch (err) {
      logger.error(err, `Error executing /${interaction.commandName}`);
      const msg = { content: "❌ An error occurred executing that command.", ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(msg).catch(() => null);
      } else {
        await interaction.reply(msg).catch(() => null);
      }
    }
  });
}
