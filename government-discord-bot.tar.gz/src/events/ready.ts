import { Client } from "discord.js";
import { logger } from "../lib/logger.js";

export function registerReadyEvent(client: Client) {
  client.once("ready", (c) => {
    logger.info(`Bot online: ${c.user.tag}`);
  });
}
