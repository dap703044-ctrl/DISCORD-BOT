import { Client, GuildMember, EmbedBuilder } from "discord.js";
import { logger } from "../lib/logger.js";

const WELCOME_CHANNEL_NAME = "welcome";
const UNVERIFIED_ROLE_NAME = "Unverified";

export function registerGuildMemberAdd(client: Client) {
  client.on("guildMemberAdd", async (member: GuildMember) => {
    logger.info(`New member joined: ${member.user.tag}`);

    const unverifiedRole = member.guild.roles.cache.find(
      (r) => r.name === UNVERIFIED_ROLE_NAME
    );
    if (unverifiedRole) {
      try {
        await member.roles.add(unverifiedRole);
        logger.info(`Assigned ${UNVERIFIED_ROLE_NAME} to ${member.user.tag}`);
      } catch (err) {
        logger.warn(err, `Could not assign ${UNVERIFIED_ROLE_NAME} role`);
      }
    }

    const welcomeChannel = member.guild.channels.cache.find(
      (c) => c.isTextBased() && c.name === WELCOME_CHANNEL_NAME
    );
    if (welcomeChannel && welcomeChannel.isTextBased()) {
      const embed = new EmbedBuilder()
        .setColor(0x1a237e)
        .setTitle("🇺🇸 Welcome to the Server")
        .setDescription(
          `Welcome, <@${member.user.id}>! Please read the rules and await verification.\n\nA staff member will verify you shortly using \`/verify\`.`
        )
        .setThumbnail(member.user.displayAvatarURL())
        .setTimestamp();

      await welcomeChannel.send({ embeds: [embed] }).catch(() => null);
    }
  });
}
