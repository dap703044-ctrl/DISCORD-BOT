import { readFileSync, writeFileSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_FILE = join(__dirname, "../../data/db.json");

interface StaffAction {
  id: string;
  staffId: string;
  staffTag: string;
  action: string;
  targetId?: string;
  targetTag?: string;
  reason?: string;
  timestamp: string;
}

interface PresidentialOrder {
  id: string;
  orderNumber: number;
  title: string;
  content: string;
  issuedBy: string;
  issuedByTag: string;
  timestamp: string;
}

interface PressRelease {
  id: string;
  title: string;
  content: string;
  author: string;
  authorTag: string;
  timestamp: string;
}

interface DailySchedule {
  date: string;
  events: Array<{ time: string; description: string }>;
  publishedAt?: string;
  publishedBy?: string;
}

interface DB {
  staffActions: StaffAction[];
  presidentialOrders: PresidentialOrder[];
  pressReleases: PressRelease[];
  schedules: DailySchedule[];
  nextOrderNumber: number;
}

function ensureDataDir() {
  const dir = join(__dirname, "../../data");
  if (!existsSync(dir)) {
    import("fs").then((fs) => fs.mkdirSync(dir, { recursive: true }));
  }
}

function loadDB(): DB {
  ensureDataDir();
  if (!existsSync(DATA_FILE)) {
    const empty: DB = {
      staffActions: [],
      presidentialOrders: [],
      pressReleases: [],
      schedules: [],
      nextOrderNumber: 1,
    };
    writeFileSync(DATA_FILE, JSON.stringify(empty, null, 2));
    return empty;
  }
  return JSON.parse(readFileSync(DATA_FILE, "utf-8")) as DB;
}

function saveDB(db: DB) {
  ensureDataDir();
  writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

export function logStaffAction(
  staffId: string,
  staffTag: string,
  action: string,
  targetId?: string,
  targetTag?: string,
  reason?: string
): StaffAction {
  const db = loadDB();
  const entry: StaffAction = {
    id: crypto.randomUUID(),
    staffId,
    staffTag,
    action,
    targetId,
    targetTag,
    reason,
    timestamp: new Date().toISOString(),
  };
  db.staffActions.push(entry);
  saveDB(db);
  return entry;
}

export function getStaffActions(limit = 20): StaffAction[] {
  const db = loadDB();
  return db.staffActions.slice(-limit).reverse();
}

export function addPresidentialOrder(
  title: string,
  content: string,
  issuedBy: string,
  issuedByTag: string
): PresidentialOrder {
  const db = loadDB();
  const order: PresidentialOrder = {
    id: crypto.randomUUID(),
    orderNumber: db.nextOrderNumber++,
    title,
    content,
    issuedBy,
    issuedByTag,
    timestamp: new Date().toISOString(),
  };
  db.presidentialOrders.push(order);
  saveDB(db);
  return order;
}

export function getPresidentialOrders(limit = 10): PresidentialOrder[] {
  const db = loadDB();
  return db.presidentialOrders.slice(-limit).reverse();
}

export function addPressRelease(
  title: string,
  content: string,
  author: string,
  authorTag: string
): PressRelease {
  const db = loadDB();
  const release: PressRelease = {
    id: crypto.randomUUID(),
    title,
    content,
    author,
    authorTag,
    timestamp: new Date().toISOString(),
  };
  db.pressReleases.push(release);
  saveDB(db);
  return release;
}

export function getPressReleases(limit = 10): PressRelease[] {
  const db = loadDB();
  return db.pressReleases.slice(-limit).reverse();
}

export function upsertSchedule(
  date: string,
  events: Array<{ time: string; description: string }>
): DailySchedule {
  const db = loadDB();
  const idx = db.schedules.findIndex((s) => s.date === date);
  const schedule: DailySchedule = { date, events };
  if (idx >= 0) {
    db.schedules[idx] = schedule;
  } else {
    db.schedules.push(schedule);
  }
  saveDB(db);
  return schedule;
}

export function getSchedule(date: string): DailySchedule | undefined {
  const db = loadDB();
  return db.schedules.find((s) => s.date === date);
}

export function markSchedulePublished(
  date: string,
  publishedBy: string
): DailySchedule | undefined {
  const db = loadDB();
  const schedule = db.schedules.find((s) => s.date === date);
  if (!schedule) return undefined;
  schedule.publishedAt = new Date().toISOString();
  schedule.publishedBy = publishedBy;
  saveDB(db);
  return schedule;
}
