import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const TICKETS_FILE = join(__dirname, "../../data/tickets.json");

export interface TicketMessage {
  authorId: string;
  authorTag: string;
  content: string;
  timestamp: string;
}

export interface Ticket {
  id: string;
  userId: string;
  userTag: string;
  channelId: string;
  status: "open" | "closed";
  subject?: string;
  openedAt: string;
  closedAt?: string;
  closedBy?: string;
  closedByTag?: string;
  transcript: TicketMessage[];
}

interface TicketDB {
  tickets: Ticket[];
  nextTicketNumber: number;
}

function ensureDataDir() {
  const dir = join(__dirname, "../../data");
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

function load(): TicketDB {
  ensureDataDir();
  if (!existsSync(TICKETS_FILE)) {
    const empty: TicketDB = { tickets: [], nextTicketNumber: 1 };
    writeFileSync(TICKETS_FILE, JSON.stringify(empty, null, 2));
    return empty;
  }
  return JSON.parse(readFileSync(TICKETS_FILE, "utf-8")) as TicketDB;
}

function save(db: TicketDB) {
  ensureDataDir();
  writeFileSync(TICKETS_FILE, JSON.stringify(db, null, 2));
}

export function getNextTicketNumber(): number {
  const db = load();
  const n = db.nextTicketNumber;
  db.nextTicketNumber++;
  save(db);
  return n;
}

export function createTicket(
  userId: string,
  userTag: string,
  channelId: string,
  subject?: string
): Ticket {
  const db = load();
  const ticket: Ticket = {
    id: crypto.randomUUID(),
    userId,
    userTag,
    channelId,
    status: "open",
    subject,
    openedAt: new Date().toISOString(),
    transcript: [],
  };
  db.tickets.push(ticket);
  save(db);
  return ticket;
}

export function getTicketByChannel(channelId: string): Ticket | undefined {
  const db = load();
  return db.tickets.find((t) => t.channelId === channelId && t.status === "open");
}

export function getOpenTicketByUser(userId: string): Ticket | undefined {
  const db = load();
  return db.tickets.find((t) => t.userId === userId && t.status === "open");
}

export function appendTranscript(channelId: string, msg: TicketMessage) {
  const db = load();
  const ticket = db.tickets.find((t) => t.channelId === channelId && t.status === "open");
  if (ticket) {
    ticket.transcript.push(msg);
    save(db);
  }
}

export function closeTicket(
  channelId: string,
  closedBy: string,
  closedByTag: string
): Ticket | undefined {
  const db = load();
  const ticket = db.tickets.find((t) => t.channelId === channelId && t.status === "open");
  if (!ticket) return undefined;
  ticket.status = "closed";
  ticket.closedAt = new Date().toISOString();
  ticket.closedBy = closedBy;
  ticket.closedByTag = closedByTag;
  save(db);
  return ticket;
}

export function getTicketsByUser(userId: string): Ticket[] {
  const db = load();
  return db.tickets.filter((t) => t.userId === userId).reverse();
}

export function getAllTickets(status?: "open" | "closed", limit = 20): Ticket[] {
  const db = load();
  const filtered = status ? db.tickets.filter((t) => t.status === status) : db.tickets;
  return filtered.slice(-limit).reverse();
}
