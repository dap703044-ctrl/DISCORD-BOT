import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { addPresidentialOrder, logStaffAction } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("order")
  .setDescription("Issue a Presidential Executive Order")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addStringOption((opt) =>
    opt.setName("title").setDescription("Title of the order").setRequired(true)
  )
  .addStringOption((opt) =>
    opt.setName("content").setDescription("Full text of the order").setRequired(true)
  )
  .addAttachmentOption((opt) =>
    opt.setName("image").setDescription("Optional image to attach to the order").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: true });

  const title = interaction.options.getString("title", true);
  const content = interaction.options.getString("content", true);
  const attachment = interaction.options.getAttachment("image");

  const order = addPresidentialOrder(title, content, interaction.user.id, interaction.user.tag);

  logStaffAction(
    interaction.user.id,
    interaction.user.tag,
    `Issued Executive Order #${order.orderNumber}: ${title}`
  );

  const issued = new Date(order.timestamp).toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const embed = new EmbedBuilder()
    .setColor(0x0a0f2c)
    .setTitle(`EXECUTIVE ORDER NO. ${order.orderNumber}`)
    .setDescription(`### ${title.toUpperCase()}\n\n${content}`)
    .addFields({ name: "Issued", value: issued, inline: true })
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  if (attachment && attachment.contentType?.startsWith("image/")) {
    embed.setImage(attachment.url);
  }

  const orderChannel = interaction.guild?.channels.cache.find(
    (c) => c.isTextBased() && c.name === "presidential-orders"
  );

  if (orderChannel && orderChannel.isTextBased()) {
    await orderChannel.send({ embeds: [embed] });
    await interaction.editReply({
      content: `Executive Order No. ${order.orderNumber} has been posted in <#${orderChannel.id}>.`,
    });
  } else {
    await interaction.followUp({ embeds: [embed] });
    await interaction.editReply({
      content: `Channel \`presidential-orders\` was not found — order posted in this channel instead.`,
    });
  }
}
