import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { logStaffAction } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("assignrole")
  .setDescription("Assign or remove a role from a member")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
  .addUserOption((opt) =>
    opt.setName("member").setDescription("Target member").setRequired(true)
  )
  .addStringOption((opt) =>
    opt.setName("role").setDescription("Role name").setRequired(true)
  )
  .addStringOption((opt) =>
    opt
      .setName("action")
      .setDescription("Add or remove the role")
      .setRequired(false)
      .addChoices(
        { name: "Add", value: "add" },
        { name: "Remove", value: "remove" }
      )
  )
  .addStringOption((opt) =>
    opt.setName("reason").setDescription("Reason for this role change").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const targetUser = interaction.options.getUser("member", true);
  const roleName = interaction.options.getString("role", true);
  const action = interaction.options.getString("action") ?? "add";
  const reason = interaction.options.getString("reason") ?? undefined;

  const member = interaction.guild?.members.cache.get(targetUser.id);
  if (!member) {
    await interaction.reply({ content: "Member not found in this server.", ephemeral: true });
    return;
  }

  const role = interaction.guild?.roles.cache.find((r) => r.name === roleName);
  if (!role) {
    await interaction.reply({
      content: `Role \`${roleName}\` does not exist on this server.`,
      ephemeral: true,
    });
    return;
  }

  if (action === "add") {
    await member.roles.add(role, reason);
  } else {
    await member.roles.remove(role, reason);
  }

  logStaffAction(
    interaction.user.id,
    interaction.user.tag,
    `${action === "add" ? "Assigned" : "Removed"} role ${roleName}`,
    targetUser.id,
    targetUser.tag,
    reason
  );

  const embed = new EmbedBuilder()
    .setColor(action === "add" ? 0x0a2a0a : 0x2a0a0a)
    .setTitle(action === "add" ? "ROLE ASSIGNED" : "ROLE REMOVED")
    .setDescription(
      `The **${roleName}** role has been ${action === "add" ? "granted to" : "revoked from"} <@${targetUser.id}>.`
    )
    .addFields(...(reason ? [{ name: "Reason", value: reason }] : []))
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
