import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionFlagsBits,
} from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("ticketpanel")
  .setDescription("Post the official support ticket panel in this channel")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addStringOption((opt) =>
    opt.setName("title").setDescription("Panel title override").setRequired(false)
  )
  .addStringOption((opt) =>
    opt.setName("description").setDescription("Panel description override").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const title = interaction.options.getString("title") ?? "OFFICIAL SUPPORT";
  const description =
    interaction.options.getString("description") ??
    "To submit an inquiry, report an issue, or request a meeting with a government official, open a private ticket below.\n\nA staff member will respond as soon as possible. Please be detailed and concise in your request.";

  const embed = new EmbedBuilder()
    .setColor(0x0a0f2c)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: "One ticket per member. Abuse of this system may result in removal." })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("ticket_open")
      .setLabel("Submit a Ticket")
      .setStyle(ButtonStyle.Primary)
  );

  await interaction.reply({ content: "Support panel has been posted.", ephemeral: true });
  if (interaction.channel && "send" in interaction.channel) {
    await interaction.channel.send({ embeds: [embed], components: [row] });
  }
}
