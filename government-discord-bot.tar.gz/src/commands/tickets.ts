import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { getAllTickets, getTicketsByUser } from "../lib/tickets.js";

export const data = new SlashCommandBuilder()
  .setName("tickets")
  .setDescription("View ticket records")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addSubcommand((sub) =>
    sub
      .setName("list")
      .setDescription("List recent tickets")
      .addStringOption((opt) =>
        opt
          .setName("status")
          .setDescription("Filter by status")
          .setRequired(false)
          .addChoices(
            { name: "Open", value: "open" },
            { name: "Closed", value: "closed" },
            { name: "All", value: "all" }
          )
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("user")
      .setDescription("View tickets submitted by a specific member")
      .addUserOption((opt) =>
        opt.setName("member").setDescription("Member to look up").setRequired(true)
      )
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const sub = interaction.options.getSubcommand();

  if (sub === "list") {
    const statusOpt = interaction.options.getString("status") ?? "all";
    const status = statusOpt === "all" ? undefined : (statusOpt as "open" | "closed");
    const tickets = getAllTickets(status, 15);

    if (tickets.length === 0) {
      await interaction.reply({ content: "No tickets found.", ephemeral: true });
      return;
    }

    const lines = tickets.map((t, i) => {
      const status = t.status === "open" ? "OPEN" : "CLOSED";
      const opened = new Date(t.openedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      return `\`${String(i + 1).padStart(2, "0")}\`  [${status}]  **${t.userTag}**  —  ${opened}  |  ${t.transcript.length} msg(s)`;
    });

    const embed = new EmbedBuilder()
      .setColor(0x0a0f2c)
      .setTitle("TICKET REGISTRY")
      .setDescription(lines.join("\n"))
      .setFooter({ text: `Showing up to 15 records — filter: ${statusOpt.toUpperCase()}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }

  if (sub === "user") {
    const user = interaction.options.getUser("member", true);
    const tickets = getTicketsByUser(user.id);

    if (tickets.length === 0) {
      await interaction.reply({
        content: `No tickets found for **${user.tag}**.`,
        ephemeral: true,
      });
      return;
    }

    const lines = tickets.slice(0, 10).map((t, i) => {
      const status = t.status === "open" ? "OPEN" : "CLOSED";
      const opened = new Date(t.openedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
      const closed = t.closedAt
        ? ` → ${new Date(t.closedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}`
        : "";
      return `\`${String(i + 1).padStart(2, "0")}\`  [${status}]  ${opened}${closed}  |  ${t.transcript.length} msg(s)`;
    });

    const embed = new EmbedBuilder()
      .setColor(0x0a0f2c)
      .setTitle("MEMBER TICKET HISTORY")
      .setDescription(`**${user.tag}**\n\n${lines.join("\n")}`)
      .setFooter({ text: `${tickets.length} total submission(s)` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
}
