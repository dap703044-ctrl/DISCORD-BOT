import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { logStaffAction } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("verify")
  .setDescription("Verify a member and assign their citizen role")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
  .addUserOption((opt) =>
    opt.setName("member").setDescription("Member to verify").setRequired(true)
  )
  .addStringOption((opt) =>
    opt
      .setName("role")
      .setDescription("Role to assign (default: Verified Citizen)")
      .setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const targetUser = interaction.options.getUser("member", true);
  const roleName = interaction.options.getString("role") ?? "Verified Citizen";

  const member = interaction.guild?.members.cache.get(targetUser.id);
  if (!member) {
    await interaction.reply({
      content: "That member could not be found in this server.",
      ephemeral: true,
    });
    return;
  }

  const role = interaction.guild?.roles.cache.find((r) => r.name === roleName);
  if (!role) {
    await interaction.reply({
      content: `The role \`${roleName}\` does not exist. Please create it before verifying members.`,
      ephemeral: true,
    });
    return;
  }

  if (member.roles.cache.has(role.id)) {
    await interaction.reply({
      content: `<@${targetUser.id}> is already verified under \`${roleName}\`.`,
      ephemeral: true,
    });
    return;
  }

  await member.roles.add(role);

  logStaffAction(
    interaction.user.id,
    interaction.user.tag,
    "Verified member",
    targetUser.id,
    targetUser.tag,
    `Assigned role: ${roleName}`
  );

  const embed = new EmbedBuilder()
    .setColor(0x0a2a0a)
    .setTitle("MEMBER VERIFIED")
    .setDescription(
      `<@${targetUser.id}> has been granted citizenship and assigned the **${roleName}** role.`
    )
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
