import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { logStaffAction } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("announce")
  .setDescription("Post an official government announcement")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addStringOption((opt) =>
    opt.setName("title").setDescription("Announcement title").setRequired(true)
  )
  .addStringOption((opt) =>
    opt.setName("message").setDescription("Announcement body").setRequired(true)
  )
  .addStringOption((opt) =>
    opt
      .setName("channel")
      .setDescription("Target channel name (defaults to announcements)")
      .setRequired(false)
  )
  .addBooleanOption((opt) =>
    opt
      .setName("ping_everyone")
      .setDescription("Ping @everyone with this announcement")
      .setRequired(false)
  )
  .addAttachmentOption((opt) =>
    opt.setName("image").setDescription("Optional image to attach to the announcement").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const title = interaction.options.getString("title", true);
  const message = interaction.options.getString("message", true);
  const channelName = interaction.options.getString("channel") ?? "announcements";
  const pingEveryone = interaction.options.getBoolean("ping_everyone") ?? false;
  const attachment = interaction.options.getAttachment("image");

  logStaffAction(interaction.user.id, interaction.user.tag, `Posted announcement: ${title}`);

  const embed = new EmbedBuilder()
    .setColor(0x0a0f2c)
    .setTitle(`OFFICIAL ANNOUNCEMENT`)
    .setDescription(`### ${title}\n\n${message}`)
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  if (attachment && attachment.contentType?.startsWith("image/")) {
    embed.setImage(attachment.url);
  }

  const targetChannel = interaction.guild?.channels.cache.find(
    (c) => c.isTextBased() && c.name === channelName
  );

  if (targetChannel && targetChannel.isTextBased()) {
    await targetChannel.send({
      content: pingEveryone ? "@everyone" : undefined,
      embeds: [embed],
    });
    await interaction.reply({
      content: `Announcement posted in <#${targetChannel.id}>.`,
      ephemeral: true,
    });
  } else {
    await interaction.reply({
      content: `Channel \`${channelName}\` was not found — posting here instead.`,
      embeds: [embed],
    });
  }
}
