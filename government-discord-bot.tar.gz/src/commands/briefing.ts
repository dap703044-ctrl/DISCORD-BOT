import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { addPressRelease, logStaffAction } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("briefing")
  .setDescription("Post an official press briefing or press release")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addStringOption((opt) =>
    opt.setName("title").setDescription("Briefing title").setRequired(true)
  )
  .addStringOption((opt) =>
    opt.setName("content").setDescription("Briefing content").setRequired(true)
  )
  .addAttachmentOption((opt) =>
    opt.setName("image").setDescription("Optional image to attach to the briefing").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const title = interaction.options.getString("title", true);
  const content = interaction.options.getString("content", true);
  const attachment = interaction.options.getAttachment("image");

  const release = addPressRelease(title, content, interaction.user.id, interaction.user.tag);

  logStaffAction(interaction.user.id, interaction.user.tag, `Posted press briefing: ${title}`);

  const issued = new Date(release.timestamp).toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const embed = new EmbedBuilder()
    .setColor(0x0d2257)
    .setTitle(`PRESS BRIEFING`)
    .setDescription(`### ${title}\n\n${content}`)
    .addFields({ name: "Date of Release", value: issued, inline: true })
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  if (attachment && attachment.contentType?.startsWith("image/")) {
    embed.setImage(attachment.url);
  }

  await interaction.reply({ embeds: [embed] });

  const pressChannel = interaction.guild?.channels.cache.find(
    (c) => c.isTextBased() && c.name === "press-releases"
  );
  if (pressChannel && pressChannel.isTextBased() && pressChannel.id !== interaction.channelId) {
    await pressChannel.send({ embeds: [embed] });
  }
}
