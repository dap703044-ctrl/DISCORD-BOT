import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import {
  upsertSchedule,
  getSchedule,
  markSchedulePublished,
  logStaffAction,
} from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("schedule")
  .setDescription("Manage and publish the Presidential Daily Schedule")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addSubcommand((sub) =>
    sub
      .setName("set")
      .setDescription("Replace the entire schedule for a date (overwrites existing events)")
      .addStringOption((opt) =>
        opt
          .setName("events")
          .setDescription('Events: "HH:MM - Description | HH:MM - Description ..."')
          .setRequired(true)
      )
      .addStringOption((opt) =>
        opt
          .setName("date")
          .setDescription("Date in YYYY-MM-DD format (leave blank for today)")
          .setRequired(false)
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("add")
      .setDescription("Add one or more events to the existing schedule")
      .addStringOption((opt) =>
        opt
          .setName("events")
          .setDescription('Events to add: "HH:MM - Description | HH:MM - Description ..."')
          .setRequired(true)
      )
      .addStringOption((opt) =>
        opt
          .setName("date")
          .setDescription("Date in YYYY-MM-DD format (leave blank for today)")
          .setRequired(false)
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("remove")
      .setDescription("Remove a specific event from the schedule by its number")
      .addIntegerOption((opt) =>
        opt
          .setName("number")
          .setDescription("Event number as shown in /schedule view")
          .setRequired(true)
          .setMinValue(1)
      )
      .addStringOption((opt) =>
        opt
          .setName("date")
          .setDescription("Date in YYYY-MM-DD format (leave blank for today)")
          .setRequired(false)
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("clear")
      .setDescription("Remove all events from a schedule")
      .addStringOption((opt) =>
        opt
          .setName("date")
          .setDescription("Date in YYYY-MM-DD format (leave blank for today)")
          .setRequired(false)
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("view")
      .setDescription("Preview a schedule without publishing")
      .addStringOption((opt) =>
        opt
          .setName("date")
          .setDescription("Date to view (leave blank for today)")
          .setRequired(false)
      )
  )
  .addSubcommand((sub) =>
    sub
      .setName("publish")
      .setDescription("Publish the schedule publicly to both schedule channels")
      .addStringOption((opt) =>
        opt
          .setName("date")
          .setDescription("Date to publish (leave blank for today)")
          .setRequired(false)
      )
      .addAttachmentOption((opt) =>
        opt
          .setName("image")
          .setDescription("Optional image to attach to the published schedule")
          .setRequired(false)
      )
  );

function todayDate() {
  return new Date().toISOString().split("T")[0];
}

function formatDate(dateStr: string) {
  const [year, month, day] = dateStr.split("-").map(Number);
  return new Date(year, month - 1, day).toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function parseEvents(raw: string) {
  return raw
    .split("|")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((entry) => {
      const sepIdx = entry.indexOf("-");
      if (sepIdx === -1) return { time: "TBD", description: entry };
      return {
        time: entry.slice(0, sepIdx).trim(),
        description: entry.slice(sepIdx + 1).trim(),
      };
    });
}

function sortEvents(events: Array<{ time: string; description: string }>) {
  return [...events].sort((a, b) => {
    const ta = a.time.replace(":", "").replace("TBD", "9999");
    const tb = b.time.replace(":", "").replace("TBD", "9999");
    return ta.localeCompare(tb);
  });
}

function buildScheduleEmbed(
  date: string,
  events: Array<{ time: string; description: string }>,
  isPublished: boolean,
  imageUrl?: string
) {
  const formattedDate = formatDate(date);
  const sorted = sortEvents(events);
  const lines = sorted
    .map((e, i) => `\`${String(i + 1).padStart(2, "0")}\`  \`${e.time}\`  —  ${e.description}`)
    .join("\n");

  const embed = new EmbedBuilder()
    .setColor(0x0a0f2c)
    .setTitle("PRESIDENTIAL DAILY SCHEDULE")
    .setDescription(`**${formattedDate}**\n\n${lines || "*No events scheduled.*"}`)
    .setFooter(
      isPublished
        ? { text: "Presidential Executive Office" }
        : { text: `DRAFT — ${events.length} event(s) — Use /schedule publish to release` }
    )
    .setTimestamp();

  if (imageUrl) {
    embed.setImage(imageUrl);
  }

  return embed;
}

export async function execute(interaction: ChatInputCommandInteraction) {
  const sub = interaction.options.getSubcommand();
  const dateOpt = interaction.options.getString("date");
  const date = dateOpt ?? todayDate();

  // ── SET (replace all) ────────────────────────────────────────────────────
  if (sub === "set") {
    const eventsRaw = interaction.options.getString("events", true);
    const events = parseEvents(eventsRaw);
    upsertSchedule(date, sortEvents(events));

    logStaffAction(
      interaction.user.id,
      interaction.user.tag,
      `Set schedule for ${date} (${events.length} event(s))`
    );

    const embed = buildScheduleEmbed(date, events, false);
    embed.addFields({
      name: "Status",
      value: `${events.length} event(s) saved. Use \`/schedule add\` to append more, or \`/schedule publish\` to release.`,
    });
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // ── ADD (append events) ──────────────────────────────────────────────────
  if (sub === "add") {
    const eventsRaw = interaction.options.getString("events", true);
    const newEvents = parseEvents(eventsRaw);
    const existing = getSchedule(date);
    const merged = sortEvents([...(existing?.events ?? []), ...newEvents]);
    upsertSchedule(date, merged);

    logStaffAction(
      interaction.user.id,
      interaction.user.tag,
      `Added ${newEvents.length} event(s) to schedule for ${date}`
    );

    const embed = buildScheduleEmbed(date, merged, false);
    embed.addFields({
      name: "Added",
      value: newEvents.map((e) => `\`${e.time}\` — ${e.description}`).join("\n"),
    });
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // ── REMOVE (delete one event by number) ──────────────────────────────────
  if (sub === "remove") {
    const num = interaction.options.getInteger("number", true);
    const existing = getSchedule(date);

    if (!existing || existing.events.length === 0) {
      await interaction.reply({
        content: `No schedule found for **${date}**.`,
        ephemeral: true,
      });
      return;
    }

    const sorted = sortEvents(existing.events);
    if (num > sorted.length) {
      await interaction.reply({
        content: `Event #${num} does not exist. The schedule for **${date}** has ${sorted.length} event(s).`,
        ephemeral: true,
      });
      return;
    }

    const removed = sorted.splice(num - 1, 1)[0];
    upsertSchedule(date, sorted);

    logStaffAction(
      interaction.user.id,
      interaction.user.tag,
      `Removed event #${num} from ${date}: ${removed.time} — ${removed.description}`
    );

    const embed = buildScheduleEmbed(date, sorted, false);
    embed.addFields({
      name: "Removed",
      value: `\`${removed.time}\` — ${removed.description}`,
    });
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // ── CLEAR (wipe all events) ───────────────────────────────────────────────
  if (sub === "clear") {
    upsertSchedule(date, []);

    logStaffAction(
      interaction.user.id,
      interaction.user.tag,
      `Cleared all events from schedule for ${date}`
    );

    await interaction.reply({
      content: `All events for **${formatDate(date)}** have been cleared.`,
      ephemeral: true,
    });
    return;
  }

  // ── VIEW ──────────────────────────────────────────────────────────────────
  if (sub === "view") {
    const schedule = getSchedule(date);
    if (!schedule || schedule.events.length === 0) {
      await interaction.reply({
        content: `No schedule found for **${formatDate(date)}**. Use \`/schedule set\` or \`/schedule add\` to create one.`,
        ephemeral: true,
      });
      return;
    }
    const embed = buildScheduleEmbed(date, schedule.events, false);
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // ── PUBLISH ───────────────────────────────────────────────────────────────
  if (sub === "publish") {
    const schedule = getSchedule(date);
    if (!schedule || schedule.events.length === 0) {
      await interaction.reply({
        content: `No schedule found for **${formatDate(date)}**. Use \`/schedule set\` or \`/schedule add\` first.`,
        ephemeral: true,
      });
      return;
    }

    const attachment = interaction.options.getAttachment("image");
    const imageUrl =
      attachment && attachment.contentType?.startsWith("image/") ? attachment.url : undefined;

    markSchedulePublished(date, interaction.user.tag);

    logStaffAction(
      interaction.user.id,
      interaction.user.tag,
      `Published presidential schedule for ${date}`
    );

    const embed = buildScheduleEmbed(date, schedule.events, true, imageUrl);
    const announcement =
      "The President's Schedule has been published. Please review it. For any issues contact the Chief Of Staff.";

    await interaction.reply({ content: announcement, embeds: [embed] });

    const SCHEDULE_CHANNEL_IDS = ["1505101243775979621", "1505101069171032095"];
    for (const channelId of SCHEDULE_CHANNEL_IDS) {
      if (channelId === interaction.channelId) continue;
      try {
        const ch = await interaction.client.channels.fetch(channelId);
        if (ch && ch.isTextBased() && "send" in ch) {
          await ch.send({ content: announcement, embeds: [embed] });
        }
      } catch {
        // channel not accessible — skip
      }
    }
  }
}
