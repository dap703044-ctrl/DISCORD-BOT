import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { getStaffActions } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("stafflog")
  .setDescription("View recent staff action records")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addIntegerOption((opt) =>
    opt
      .setName("limit")
      .setDescription("Number of records to retrieve (max 20)")
      .setRequired(false)
      .setMinValue(1)
      .setMaxValue(20)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const limit = interaction.options.getInteger("limit") ?? 10;
  const actions = getStaffActions(limit);

  if (actions.length === 0) {
    await interaction.reply({ content: "No staff actions have been recorded yet.", ephemeral: true });
    return;
  }

  const lines = actions.map((a, i) => {
    const ts = new Date(a.timestamp).toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
    const target = a.targetTag ? ` → ${a.targetTag}` : "";
    const reason = a.reason ? `\n  Reason: ${a.reason}` : "";
    return `\`${String(i + 1).padStart(2, "0")}\`  **${a.staffTag}**${target}\n  ${a.action}${reason}\n  *${ts}*`;
  });

  const embed = new EmbedBuilder()
    .setColor(0x0a0f2c)
    .setTitle("STAFF ACTION RECORD")
    .setDescription(lines.join("\n\n"))
    .setFooter({ text: `${actions.length} record(s) retrieved` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed], ephemeral: true });
}
