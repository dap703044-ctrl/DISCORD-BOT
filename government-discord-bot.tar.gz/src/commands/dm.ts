import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
  User,
  GuildMember,
} from "discord.js";
import { logStaffAction } from "../lib/db.js";

export const data = new SlashCommandBuilder()
  .setName("dm")
  .setDescription("Send an official DM to specific officials and/or entire roles")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addStringOption((opt) =>
    opt.setName("subject").setDescription("Subject of the correspondence").setRequired(true)
  )
  .addStringOption((opt) =>
    opt.setName("message").setDescription("Body of the message").setRequired(true)
  )
  .addStringOption((opt) =>
    opt
      .setName("type")
      .setDescription("Type of communication")
      .setRequired(false)
      .addChoices(
        { name: "Meeting Request", value: "meeting" },
        { name: "Briefing", value: "briefing" },
        { name: "Official Notice", value: "notice" },
        { name: "General Message", value: "general" }
      )
  )
  .addAttachmentOption((opt) =>
    opt.setName("image").setDescription("Optional image to include in the DM").setRequired(false)
  )
  // Individual recipients
  .addUserOption((opt) =>
    opt.setName("recipient1").setDescription("Individual recipient #1").setRequired(false)
  )
  .addUserOption((opt) =>
    opt.setName("recipient2").setDescription("Individual recipient #2").setRequired(false)
  )
  .addUserOption((opt) =>
    opt.setName("recipient3").setDescription("Individual recipient #3").setRequired(false)
  )
  .addUserOption((opt) =>
    opt.setName("recipient4").setDescription("Individual recipient #4").setRequired(false)
  )
  .addUserOption((opt) =>
    opt.setName("recipient5").setDescription("Individual recipient #5").setRequired(false)
  )
  // Role recipients
  .addRoleOption((opt) =>
    opt.setName("role1").setDescription("DM all members with this role").setRequired(false)
  )
  .addRoleOption((opt) =>
    opt.setName("role2").setDescription("DM all members with this role").setRequired(false)
  )
  .addRoleOption((opt) =>
    opt.setName("role3").setDescription("DM all members with this role").setRequired(false)
  );

const TYPE_LABELS: Record<string, string> = {
  meeting: "MEETING REQUEST",
  briefing: "BRIEFING",
  notice: "OFFICIAL NOTICE",
  general: "CORRESPONDENCE",
};

export async function execute(interaction: ChatInputCommandInteraction) {
  await interaction.deferReply({ ephemeral: true });

  const subject = interaction.options.getString("subject", true);
  const message = interaction.options.getString("message", true);
  const type = interaction.options.getString("type") ?? "general";
  const typeLabel = TYPE_LABELS[type] ?? TYPE_LABELS.general;
  const attachment = interaction.options.getAttachment("image");

  // ── Collect individual user recipients ───────────────────────────────────
  const individualUsers: User[] = [
    interaction.options.getUser("recipient1"),
    interaction.options.getUser("recipient2"),
    interaction.options.getUser("recipient3"),
    interaction.options.getUser("recipient4"),
    interaction.options.getUser("recipient5"),
  ].filter((u): u is User => u !== null);

  // ── Collect role members ─────────────────────────────────────────────────
  const roleOptions = [
    interaction.options.getRole("role1"),
    interaction.options.getRole("role2"),
    interaction.options.getRole("role3"),
  ].filter(Boolean);

  const roleNames: string[] = roleOptions.map((r) => r!.name);

  // Build the set of users to DM (deduplicated by ID)
  const recipientMap = new Map<string, User>();

  for (const user of individualUsers) {
    recipientMap.set(user.id, user);
  }

  // Fetch guild members for each role and add to the map
  if (roleOptions.length > 0 && interaction.guild) {
    try {
      // Fetch members from API so we have an up-to-date list
      await interaction.guild.members.fetch();
    } catch {
      // If fetch fails, fall back to cache only
    }

    for (const role of roleOptions) {
      if (!role) continue;
      const guildRole = interaction.guild.roles.cache.get(role.id);
      if (!guildRole) continue;
      for (const [, member] of guildRole.members) {
        if (!member.user.bot) {
          recipientMap.set(member.user.id, member.user);
        }
      }
    }
  }

  if (recipientMap.size === 0) {
    await interaction.editReply({
      content: "You must specify at least one recipient (user or role).",
    });
    return;
  }

  // ── Build the embed ───────────────────────────────────────────────────────
  const embed = new EmbedBuilder()
    .setColor(0x0a0f2c)
    .setTitle(typeLabel)
    .setDescription(`**Re: ${subject}**\n\n${message}`)
    .setFooter({ text: "Presidential Executive Office — Official Government Communication" })
    .setTimestamp();

  if (attachment && attachment.contentType?.startsWith("image/")) {
    embed.setImage(attachment.url);
  }

  // ── Send DMs ─────────────────────────────────────────────────────────────
  const delivered: string[] = [];
  const failed: string[] = [];

  for (const [, user] of recipientMap) {
    try {
      await user.send({ embeds: [embed] });
      delivered.push(user.tag);
    } catch {
      failed.push(user.tag);
    }
  }

  if (delivered.length > 0) {
    logStaffAction(
      interaction.user.id,
      interaction.user.tag,
      `Sent ${typeLabel} to ${delivered.length} recipient(s)${roleNames.length > 0 ? ` (roles: ${roleNames.join(", ")})` : ""} — Re: ${subject}`
    );
  }

  // ── Transmission report ───────────────────────────────────────────────────
  const confirmEmbed = new EmbedBuilder()
    .setColor(failed.length === recipientMap.size ? 0x2a0a0a : 0x0a2a0a)
    .setTitle("TRANSMISSION REPORT")
    .addFields(
      { name: "Subject", value: subject },
      { name: "Type", value: typeLabel }
    );

  if (roleNames.length > 0) {
    confirmEmbed.addFields({
      name: "Roles Targeted",
      value: roleNames.map((n) => `— ${n}`).join("\n"),
    });
  }

  if (delivered.length > 0) {
    // Show up to 20 names to avoid embed field limit
    const preview = delivered.slice(0, 20);
    const overflow = delivered.length - preview.length;
    confirmEmbed.addFields({
      name: `Delivered (${delivered.length})`,
      value:
        preview.map((t) => `— ${t}`).join("\n") +
        (overflow > 0 ? `\n*…and ${overflow} more*` : ""),
    });
  }

  if (failed.length > 0) {
    const preview = failed.slice(0, 10);
    const overflow = failed.length - preview.length;
    confirmEmbed.addFields({
      name: `Failed (${failed.length})`,
      value:
        preview.map((t) => `— ${t} *(DMs may be disabled)*`).join("\n") +
        (overflow > 0 ? `\n*…and ${overflow} more*` : ""),
    });
  }

  confirmEmbed.setTimestamp();

  await interaction.editReply({ embeds: [confirmEmbed] });
}
