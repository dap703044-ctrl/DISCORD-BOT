import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { getTicketByChannel, closeTicket } from "../lib/tickets.js";
import { logStaffAction } from "../lib/db.js";
import { logger } from "../lib/logger.js";

export const data = new SlashCommandBuilder()
  .setName("closeticket")
  .setDescription("Close and remove the current ticket channel")
  .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
  .addStringOption((opt) =>
    opt.setName("reason").setDescription("Reason for closure").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const reason = interaction.options.getString("reason") ?? "No reason provided";
  const channelId = interaction.channelId;

  const ticket = getTicketByChannel(channelId);
  if (!ticket) {
    await interaction.reply({
      content: "This channel is not an active ticket.",
      ephemeral: true,
    });
    return;
  }

  await interaction.deferReply();

  const closed = closeTicket(channelId, interaction.user.id, interaction.user.tag);
  if (!closed) {
    await interaction.editReply({ content: "Unable to close this ticket. Please try again." });
    return;
  }

  logStaffAction(
    interaction.user.id,
    interaction.user.tag,
    `Closed ticket for ${ticket.userTag} — ${reason}`,
    ticket.userId,
    ticket.userTag,
    reason
  );

  const TICKET_LOG_CHANNEL_NAME = "ticket-logs";
  const logChannel = interaction.guild?.channels.cache.find(
    (c) => c.isTextBased() && c.name === TICKET_LOG_CHANNEL_NAME
  );

  if (logChannel && logChannel.isTextBased()) {
    const logEmbed = new EmbedBuilder()
      .setColor(0x0a0f2c)
      .setTitle("TICKET RECORD")
      .addFields(
        { name: "Submitted By", value: ticket.userTag, inline: true },
        { name: "Closed By", value: interaction.user.tag, inline: true },
        { name: "Reason", value: reason }
      )
      .setTimestamp();
    await logChannel.send({ embeds: [logEmbed] });
  }

  const embed = new EmbedBuilder()
    .setColor(0x2a0a0a)
    .setTitle("TICKET CLOSED")
    .setDescription(`This ticket has been closed.\n\n**Reason:** ${reason}\n\nThis channel will be removed in 5 seconds.`)
    .setFooter({ text: "Presidential Executive Office" })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed] });

  setTimeout(async () => {
    try {
      await interaction.channel?.delete("Ticket closed");
    } catch {
      logger.warn("Could not delete ticket channel");
    }
  }, 5000);
}
