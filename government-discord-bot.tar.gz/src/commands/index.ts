import { ChatInputCommandInteraction } from "discord.js";
import * as order from "./order.js";
import * as briefing from "./briefing.js";
import * as alert from "./alert.js";
import * as schedule from "./schedule.js";
import * as dm from "./dm.js";
import * as announce from "./announce.js";
import * as verify from "./verify.js";
import * as assignrole from "./assignrole.js";
import * as stafflog from "./stafflog.js";
import * as ticketpanel from "./ticketpanel.js";
import * as closeticket from "./closeticket.js";
import * as tickets from "./tickets.js";

export interface Command {
  data: { name: string; toJSON: () => unknown };
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

export const commands: Command[] = [
  order,
  briefing,
  alert,
  schedule,
  dm,
  announce,
  verify,
  assignrole,
  stafflog,
  ticketpanel,
  closeticket,
  tickets,
];

export const commandMap = new Map<string, Command>(
  commands.map((c) => [c.data.name, c])
);
