import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import { logStaffAction } from "../lib/db.js";

const ALERT_LEVELS: Record<string, { color: number; label: string; banner: string }> = {
  info:      { color: 0x1a3a6b, label: "INFORMATION",  banner: "— OFFICIAL NOTICE —" },
  warning:   { color: 0x7a4a00, label: "WARNING",       banner: "— GOVERNMENT WARNING —" },
  critical:  { color: 0x6b0000, label: "CRITICAL",      banner: "— CRITICAL ALERT —" },
  emergency: { color: 0x2d0000, label: "EMERGENCY",     banner: "— NATIONAL EMERGENCY —" },
};

export const data = new SlashCommandBuilder()
  .setName("alert")
  .setDescription("Broadcast a government alert to the server")
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addStringOption((opt) =>
    opt
      .setName("level")
      .setDescription("Alert severity level")
      .setRequired(true)
      .addChoices(
        { name: "Info", value: "info" },
        { name: "Warning", value: "warning" },
        { name: "Critical", value: "critical" },
        { name: "Emergency", value: "emergency" }
      )
  )
  .addStringOption((opt) =>
    opt.setName("message").setDescription("Alert message").setRequired(true)
  )
  .addStringOption((opt) =>
    opt
      .setName("channel")
      .setDescription("Channel name to broadcast in (defaults to current channel)")
      .setRequired(false)
  )
  .addAttachmentOption((opt) =>
    opt.setName("image").setDescription("Optional image to attach to the alert").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const level = interaction.options.getString("level", true);
  const message = interaction.options.getString("message", true);
  const targetChannelName = interaction.options.getString("channel");
  const attachment = interaction.options.getAttachment("image");

  const { color, label, banner } = ALERT_LEVELS[level] ?? ALERT_LEVELS.info;

  logStaffAction(
    interaction.user.id,
    interaction.user.tag,
    `Issued ${label} alert: ${message.slice(0, 60)}`
  );

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(banner)
    .setDescription(`**SEVERITY: ${label}**\n\n${message}`)
    .setFooter({ text: "Presidential Executive Office — Official Government Broadcast" })
    .setTimestamp();

  if (attachment && attachment.contentType?.startsWith("image/")) {
    embed.setImage(attachment.url);
  }

  await interaction.reply({ embeds: [embed] });

  if (targetChannelName) {
    const targetChannel = interaction.guild?.channels.cache.find(
      (c) => c.isTextBased() && c.name === targetChannelName
    );
    if (targetChannel && targetChannel.isTextBased() && targetChannel.id !== interaction.channelId) {
      await targetChannel.send({ content: "@everyone", embeds: [embed] });
    }
  }
}
