import { REST, Routes } from "discord.js";
import { commands } from "./commands/index.js";
import { logger } from "./lib/logger.js";

const token = process.env.DISCORD_BOT_TOKEN;
const guildId = process.env.DISCORD_GUILD_ID;

if (!token || !guildId) {
  logger.error("Missing DISCORD_BOT_TOKEN or DISCORD_GUILD_ID");
  process.exit(1);
}

const rest = new REST({ version: "10" }).setToken(token);

const commandData = commands.map((c) => c.data.toJSON());

try {
  logger.info(`Deploying ${commandData.length} slash commands to guild ${guildId}...`);

  const clientId = Buffer.from(token.split(".")[0], "base64").toString("utf-8");

  await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
    body: commandData,
  });

  logger.info("Successfully deployed all slash commands.");
} catch (err) {
  logger.error(err, "Failed to deploy commands");
  process.exit(1);
}
