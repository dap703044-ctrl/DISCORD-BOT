import { Client, GatewayIntentBits, Partials } from "discord.js";
import { logger } from "./lib/logger.js";
import { registerReadyEvent } from "./events/ready.js";
import { registerInteractionCreate } from "./events/interactionCreate.js";
import { registerMessageCreate } from "./events/messageCreate.js";
import { registerButtonInteraction } from "./events/buttonInteraction.js";
import { registerTicketMessageTracking } from "./events/ticketMessages.js";

const token = process.env.DISCORD_BOT_TOKEN;

if (!token) {
  logger.error("DISCORD_BOT_TOKEN is not set");
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message],
});

registerReadyEvent(client);
registerInteractionCreate(client);
registerMessageCreate(client);
registerButtonInteraction(client);
registerTicketMessageTracking(client);

client.login(token).catch((err) => {
  logger.error(err, "Failed to login to Discord");
  process.exit(1);
});
